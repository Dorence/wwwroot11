"use strict";
var chrome=chrome;

if(typeof module==="object"){window.jQuery=window.$=module.exports;};

function Freload()
{
	$("#pp").html("Reloading!");
	chrome.runtime.reload();
}

$("#btt").on("click",function(){Freload();});

chrome.runtime.sendMessage({type:"pop.js-start"}, function(response){
	console.log(response);
    $("#pp").append(response.text);
});

/*
chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
	console.log("pop.js get");
	console.log(message);
    if(message.type&&message.type==="login")
	{
		$("#pp").append("login");
		document.getElementById("btnA").disabled=!!message.flaglogin;
        sendResponse({text:'Get data:login'});
    }
});
*/
/*
var port = chrome.runtime.connect({name: "pop.js-port"});
console.log(port);
port.postMessage({joke:"pop敲门"});
port.onMessage.addListener(function(msg){
	console.log(msg);
	if(msg.question === "是谁？")
	port.postMessage({answer: "女士"});
	else if (msg.question === "哪位女士？")
	port.postMessage({answer: "Bovary 女士"});
	if(msg.type==="login")
	{
		$("#pp").html("Detect Login!");
		document.getElementById("btnA").disabled=false;
	}
});*/

var port;

$("#btnA").on("click",function(){
	port = chrome.runtime.connect({name: "pop.js-port"});
	console.log(port);
	port.postMessage({cmd:"login"});
	/*port.onMessage.addListener(function(msg){
	console.log(msg);
	if(msg.question === "是谁？")
	port.postMessage({answer: "女士"});
	else if (msg.question === "哪位女士？")
	port.postMessage({answer: "Bovary 女士"});
	if(msg.type==="login")
	{
		$("#pp").html("Detect Login!");
	}
	});*/
});

