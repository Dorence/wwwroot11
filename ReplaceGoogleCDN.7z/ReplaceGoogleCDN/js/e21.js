"use strict";
var chrome=chrome;

console.log("e21.js on");
console.log(location.href);

var portPop;

function proc()
{
	switch(location.hostname)
	{
		case "gzkg.e21.cn":
		console.log("here gzkg.e21.cn");
		switch(location.pathname)
		{
			case "/login/login1.php":
				console.log("here login/login1.php");
				
				chrome.runtime.sendMessage({type:"login",href:location.href},function(response){
					console.log(response);
				});
				
				portPop = chrome.runtime.connect({name: "pop.js-port"});
				console.log(portPop);
				portPop.postMessage({type:"login"});
				portPop.onMessage.addListener(function(msg){
					console.log("e21.js get pop.js-port");
					console.log(msg);
					if(msg.question === "pop敲门")
					{
						portPop.postMessage({type:"login"});
					}
				});
				console.log("add pop.js listener done!");
				
			break;
		}
		
		
		break;
	}
	
}

chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
	console.log("e21.js get");
	console.log(message);
    if(message.type&&message.type==="pop.js-start"){
		proc();
    }
});

var port = chrome.runtime.connect({name: "敲门"});

console.log(port);
port.postMessage({joke:"敲门"});
port.onMessage.addListener(function(msg){
	console.log("e21.js get");
	console.log(msg);
	if(msg.question === "是谁？")
	port.postMessage({answer: "女士"});
	else if (msg.question === "哪位女士？")
	port.postMessage({answer: "Bovary 女士"});
});
console.log("add listener done!");

console.log("e21.js done");

proc();

function shit()
{
	console.log("shit on");
	chrome.runtime.onConnect.addListener(function(port){
	console.log("e21.js get port:"+port.name);
	console.log(port);
	if(port.name==="login-port")
	{
		loginX();
	}
	
});
}

//setInterval("shit()",2000);


function loginX()
{
	$("#UserType").val(2);
	$("#UserName").val("hsy303");
	$("#UserPwd").val("030201");
	document.getElementById("userYzm").focus();
}





