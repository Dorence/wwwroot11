"use strict";
var chrome=chrome;
var P=chrome.runtime.getURL;
var A="assets/";
var AG="assets/github/";
var G="https://assets-cdn.github.com/assets/";
var get={};
var cnt=0;

var par=[
[/https?:\/\/gzkg\.e21\.cn\/js\/jquery\.js/,P(A+"jquery-1.4.4.min.js"),true],[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/1/i,P(A+"jquery-1.12.4.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/2/i,P(A+"jquery-2.2.4.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/3/i,P(A+"jquery-3.3.1.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jqueryui\/1(([0-9]|\.)*)\/jquery-ui(\.min)?\.js/i,P(A+"jquery-ui-1.12.1.min.js"),true],
[G+"github-8b5319d072aa221393f06aa08cd8a12c.css",P(AG+"github-8b5319d072aa221393f06aa08cd8a12c.css"),true],
[G+"github-f3dbefb182d184a7c6bf518633cfcb38.css",P(AG+"github-f3dbefb182d184a7c6bf518633cfcb38.css"),true],
[G+"github-5bda2505b1bf6652fe8e5a45648e7a83.css",P(AG+"github-5bda2505b1bf6652fe8e5a45648e7a83.css"),true],
[G+"frameworks-23c9e7262eee71bc6f67f6950190a162.css",P(AG+"frameworks-githublight-0.4.1.css"),true],
[G+"github-b5ffe6e7dc9195ef4d6fc74858e4372f.js",P(AG+"github-b5ffe6e7dc9195ef4d6fc74858e4372f.js"),true],
[G+"frameworks-69305c61e4ce67cdef4a70845fc0e959.js",P(AG+"github/frameworks-69305c61e4ce67cdef4a70845fc0e959.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\//i,'https://cdn.bootcss.com/jquery/'],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jqueryui\//i,'https://cdn.bootcss.com/jqueryui/'],
['googleapis.com','lug.ustc.edu.cn'],
['themes.googleusercontent.com','google-themes.lug.ustc.edu.cn'],
[/https?:\/\/[A-z]*.e21.cn\/html\/advertisement\/([0-9]|\/)+_[0-9]+(_s\.jpg|\.jpg|_s\.gif)/,P(A+"ad.jpg"),true],
[/https?:\/\/gzkg\.e21\.cn\/images\/dlgg[0-9]*.gif/,P(A+"ad.jpg"),true],
[/https?:\/\/csdnimg\.cn\/public\/common\/libs\/jquery\/jquery-1(([0-9]|\.)*)(\.min)?.js/,P(A+"jquery-1.12.4.min.js"),true]
];
console.log(par);

chrome.webRequest.onBeforeRequest.addListener(
    function(request) {
        var url = request.url;
		for(var i = 0;i < par.length;i++)
		{
			if(url.search(par[i][0])>=0)
			{
				//console.log(request);
				console.log(url);
				console.log(par[i][1]);
				chrome.browserAction.setBadgeText({text: String(++cnt)});
				if(par[i][2]){ return {redirectUrl: par[i][1]}; }
				else{ return {redirectUrl: url.replace(par[i][0],par[i][1])}; }
			}
		}
        return {};
    },
    {
        urls: [
            "*://*.e21.cn/*",
			"*://ajax.googleapis.com/*",
            "*://themes.googleusercontent.com/*",
			"*://assets-cdn.github.com/assets/*",
			"*://csdnimg.cn/public/common/libs/*"
        ]
    },
    ["blocking"]
);

chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
	console.log(message);
	/*chrome.windows.get(chrome.windows.WINDOW_ID_CURRENT,function(win){
		 console.log(win);
	 });*/
    if(message.type&&message.type==="pop.js-start"){
        sendResponse({text:'Hello from bg.',flaglogin:get.login});
		//chrome.runtime.sendMessage({type:"e21.js-ping"},function(response){
		if(get.login){
			console.log("prepare to send ping to e21.js");
			chrome.tabs.sendMessage(get.loginid,{type:"e21.js-ping"}, function(response){
				console.log(response);
			});
		}
    }
	else if(message.type&&message.type==="login"){
		get.login=true;
		chrome.windows.get(chrome.windows.WINDOW_ID_CURRENT,function(win){
			console.log(win);
			console.log(get.loginid=win.id);
		});
		return {id:get.loginid};
    }
	
});

var port1 = chrome.runtime.connect({name: "login-port"});

chrome.runtime.onConnect.addListener(function(port){
	console.log("get port:"+port.name);
	console.log(port);
	if(port.name==="敲门")
	{
		port.onMessage.addListener(function(msg){
			console.log(msg);
		if (msg.joke === "敲门")
		  port.postMessage({question: "是谁？"});
		else if (msg.answer === "女士")
		  port.postMessage({question: "哪位女士？"});
		else if (msg.answer === "Bovary 女士")
		  port.postMessage({question: "我没听清楚。"});
		});
	}
	else if(port.name==="pop.js-port")
	{
		port.onMessage.addListener(function(msg){
			console.log(msg);
			port1 = chrome.runtime.connect({name: "login-port"});
			if(msg.cmd==="login")
			{
				console.log(port1);
				port1.postMessage({cmd:"login"});
			}
		});
	}
	
});




