
console.log("66ys.js on");
console.log(location.href);

var boxList=["HMRichBox","ETE","lgVshow"];
console.log(boxList);

function clearBox()
{
	"use strict";
	console.log("clear");
	var x;
	for(var i=0;i<boxList.length;i++)
	{
		x=document.getElementById(boxList[i]);
		if(x){x.parentNode.removeChild(x);}
	}
}

clearBox();
setInterval("clearBox()",5000);
