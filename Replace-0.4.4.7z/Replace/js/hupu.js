
console.log("hupu.js on");
console.log(location.href);

var boxList=[["cBox-A voteIndex"]];
console.log(boxList);

function clearBox()
{
	"use strict";
	console.log("clear");
	var x;
	for(var i=0;i<boxList.length;i++)
	{
		if(boxList[i][0])
		{
			x=document.getElementsByClassName(boxList[i][0]);
			for(var j=0;j<x.length;j++)
			{
				x[i].parentNode.removeChild(x[i]);
			}
		}
		else
		{
			x=document.getElementById(boxList[i]);
			if(x){x.parentNode.removeChild(x);}
		}
	}
}

clearBox();
setInterval("clearBox()",5000);
