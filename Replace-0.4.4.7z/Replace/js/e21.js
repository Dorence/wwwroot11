"use strict";

console.log("e21.js on");
console.log(location.href);

function loginX()
{
	document.getElementById('UserType').value=2;
	document.getElementById('UserName').value='hsy303';
	document.getElementById('UserPwd').value='030201';
	document.getElementById('userYzm').focus();
	console.log('print done');
}





