"use strict";
var chrome=chrome;
var P=chrome.runtime.getURL;
var G="https://assets-cdn.github.com/assets/";
var get={};
var cnt=0;

function L(flag,r)
{
	var q=["","assets/","assets/github/","assets/fonts/"];
	return P(q[flag]+r);
}

var par=[
[/https?:\/\/gzkg\.e21\.cn\/js\/jquery\.js/,L(1,"jquery-1.4.4.min.js"),true],[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/1/i,L(1,"jquery-1.12.4.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/2/i,L(1,"jquery-2.2.4.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\/3/i,L(1,"jquery-3.3.1.min.js"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jqueryui\/1(([0-9]|\.)*)\/jquery-ui(\.min)?\.js/i,L(1,"jquery-ui-1.12.1.min.js"),true],

[G+"github-8b5319d072aa221393f06aa08cd8a12c.css",L(2,"github-8b5319d072aa221393f06aa08cd8a12c.css"),true],
[G+"github-f3dbefb182d184a7c6bf518633cfcb38.css",L(2,"github-f3dbefb182d184a7c6bf518633cfcb38.css"),true],
[G+"github-f33d51cdc14ddc36995b2e42a6259a0b.css",L(2,"github-f33d51cdc14ddc36995b2e42a6259a0b.css"),true],
[G+"github-5bda2505b1bf6652fe8e5a45648e7a83.css",L(2,"github-5bda2505b1bf6652fe8e5a45648e7a83.css"),true],
[G+"github-2fad8068e34216f8839577b18d1ecc23.css",L(2,"github-2fad8068e34216f8839577b18d1ecc23.css"),true],
[G+"frameworks-23c9e7262eee71bc6f67f6950190a162.css",L(2,"frameworks-githublight-0.4.1.css"),true],

[G+"github-5eb5a0a782f98fd2a446939b2f7cecf7.js",L(2,"github-5eb5a0a782f98fd2a446939b2f7cecf7.js"),true],
[G+"github-b373bd0192b235b33334634b93f6d34b.js",L(2,"github-b373bd0192b235b33334634b93f6d34b.js"),true],
[G+"github-b5ffe6e7dc9195ef4d6fc74858e4372f.js",L(2,"github-b5ffe6e7dc9195ef4d6fc74858e4372f.js"),true],

[G+"frameworks-2afbd5df19ed1f9aaf0a04c15e9d0b35.js",L(2,"frameworks-2afbd5df19ed1f9aaf0a04c15e9d0b35.js"),true],
[G+"frameworks-69305c61e4ce67cdef4a70845fc0e959.js",L(2,"frameworks-69305c61e4ce67cdef4a70845fc0e959.js"),true],

["https://assets-cdn.github.com/images/modules/site/site-signup-prompt.png",L(2,"png/site-signup-prompt.png"),true],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jquery\//i,'https://cdn.bootcss.com/jquery/'],
[/https?:\/\/ajax\.googleapis\.com\/ajax\/libs\/jqueryui\//i,'https://cdn.bootcss.com/jqueryui/'],
['googleapis.com','lug.ustc.edu.cn'],
['themes.googleusercontent.com','google-themes.lug.ustc.edu.cn'],
[/https?:\/\/[A-z]*.e21.cn\/html\/advertisement\/([0-9]|\/)+_[0-9]+(_s\.jpg|\.jpg|_s\.gif)/,L(1,"ad.png"),true],
[/https?:\/\/gzkg\.e21\.cn\/images\/dlgg[0-9]*.gif/,L(1,"ad.png"),true],
[/https?:\/\/tpc\.googlesyndication\.com\/pagead\/imgad/,L(1,"ad.png"),true],
[/https?:\/\/tpc\.googlesyndication\.com\/pagead\/js/,L(1,"null.js"),true],	
[/https?:\/\/tpc\.googlesyndication\.com\/daca_images\/simgad\//,L(1,"ad.png"),true],
[/https?:\/\/t1\.hoopchina\.com\.cn\/img\/1?[0-9]{11}\.jpg/,L(1,"ad.png"),true],
[/https?:\/\/csdnimg\.cn\/public\/common\/libs\/jquery\/jquery-1(([0-9]|\.)*)(\.min)?.js/,L(1,"jquery-1.12.4.min.js"),true],
[/https?:\/\/static\.googleadsserving\.cn\/pagead\/imgad/,L(1,"ad.png"),true],
["http://wa.gtimg.com/website/201804/jdnbpe_EF_20180413161116288.jpg",L(1,"ad.png"),true],
["http://wa.gtimg.com/website/201804/jdnbpe_EF_2018041316111141.jpg",L(1,"ad.png"),true],
["http://www.66ys.tv/d/960x90.gif",L(1,"ad.png"),true],
[/https?:\/\/gg\.qucaigg\.com:[0-9]{2,5}\/960-90-[0-9]*.gif/,L(1,"ad.png"),true],
[/https?:\/\/lg3\.jointreport-switch\.com\/html\/[0-9]*\/[^\s]*.(gif|jpg)/,L(1,"ad.png"),true],
	

[/https?:\/\/ad\.wang502\.com\/ad?/,L(1,"null.js"),true],
	
[/https?:\/\/safe-aisle\.jointreport-switch\.com\/(display|export)\.php?/,L(1,"null.html"),true],
[/https?:\/\/cpv-adv\.ggytc\.com:[0-9]*\/AD\/View\.aspx/,L(1,"null.html"),true],
[/https?:\/\/jsjs\.nthyn\.com\/v\.php?/,L(1,"null.html"),true],
[/https?:\/\/googleads\.g\.doubleclick\.net\/pagead\/ads?/,L(1,"null.html"),true],

["http://zh.cppreference.com/DejaVuSans.ttf",L(3,"DejaVuSans.ttf"),true],
["http://zh.cppreference.com/DejaVuSans-Bold.ttf",L(3,"DejaVuSans-Bold.ttf"),true],
["http://zh.cppreference.com/DejaVuSansMono.ttf",L(3,"DejaVuSansMono.ttf"),true],

["https://assets-cdn.github.com/static/fonts/roboto/roboto-italic.woff",L(3,"roboto-italic.woff"),true],
["https://assets-cdn.github.com/static/fonts/roboto/roboto-light.woff",L(3,"roboto-light.woff"),true],
["https://assets-cdn.github.com/static/fonts/roboto/roboto-medium.woff",L(3,"roboto-medium.woff"),true],
["https://assets-cdn.github.com/static/fonts/roboto/roboto-regular.woff",L(3,"roboto-regular.woff"),true],
	
[/https?:\/\/img-ads\.csdn\.net\/20[0-9]{2}\/20[0-9]{6}[0-9]+\.(gif|jpg|png)/,L(1,"ad.png"),true]

];

console.log(par);
chrome.browserAction.setBadgeText({text:""});

chrome.webRequest.onBeforeRequest.addListener(
    function(request) {
        var url = request.url;
		for(var i = 0;i < par.length;i++)
		{
			if(url.search(par[i][0])>=0)
			{
				//console.log(request);
				console.log(url);
				console.log(par[i][1]);
				chrome.browserAction.setBadgeText({text: String(++cnt)});
				if(par[i][2]){ return {redirectUrl: par[i][1]}; }
				else{ return {redirectUrl: url.replace(par[i][0],par[i][1])}; }
			}
		}
        return {};
    },
    {
        urls: [
            "*://*.e21.cn/*",
			"*://ajax.googleapis.com/*",
            "*://themes.googleusercontent.com/*",
			"*://assets-cdn.github.com/*",
			"*://csdnimg.cn/public/common/libs/*",
			"*://tpc.googlesyndication.com/pagead/*",
			"*://tpc.googlesyndication.com/daca_images/simgad/*",
			"*://static.googleadsserving.cn/pagead/*",
			"*://t1.hoopchina.com.cn/img/*",
			"*://wa.gtimg.com/website/*",
			"*://www.66ys.tv/d/*",
			"*://*.jointreport-switch.com/*",
			"*://ad.wang502.com/ad*",
			"*://gg.qucaigg.com:*/*",
			"*://zh.cppreference.com/*",
			"*://jsjs.nthyn.com/*",
			"*://img-ads.csdn.net/*",
			"*://googleads.g.doubleclick.net/pagead/*"
        ]
    },
    ["blocking"]
);

/*chrome.windows.get(chrome.windows.WINDOW_ID_CURRENT,function(win){console.log(win);});*/

chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
	console.log(message);
	
    if(message.type&&message.type==="pop.js-start"){
        sendResponse({text:'Hello from bg.',flaglogin:get.login});
		//chrome.runtime.sendMessage({type:"e21.js-ping"},function(response){
		if(get.login){
			console.log("prepare to send ping to e21.js");
			chrome.tabs.sendMessage(get.loginid,{type:"e21.js-ping"}, function(response){
				console.log(response);
			});
		}
    }
	else if(message.type&&message.type==="login"){
		get.login=true;
		chrome.windows.get(chrome.windows.WINDOW_ID_CURRENT,function(win){
			console.log(win);
			console.log(get.loginid=win.id);
		});
		return {id:get.loginid};
    }
	
});

//var port1 = chrome.runtime.connect({name: "login-port"});

chrome.runtime.onConnect.addListener(function(port){
	console.log("get port:"+port.name);
	console.log(port);
	if(port.name==="敲门")
	{
		/*port.onMessage.addListener(function(msg){
			console.log(msg);
		if (msg.joke === "敲门")
		  port.postMessage({question: "是谁？"});
		else if (msg.answer === "女士")
		  port.postMessage({question: "哪位女士？"});
		else if (msg.answer === "Bovary 女士")
		  port.postMessage({question: "我没听清楚。"});
		});*/
	}
	else if(port.name==="pop.js-port")
	{
		port.onMessage.addListener(function(msg){
			console.log(msg);
			if(msg.cmd==="login")
			{
				var wid;
				chrome.windows.get(-2,function(win){console.log(win);wid=win.id;});
				console.log(wid);
				chrome.tabs.executeScript(wid,{code:"loginX();"});
			}
		});
	}
});

